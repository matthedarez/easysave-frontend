import React from 'react'
import { apiBase, saveAuth } from '../lib/api'

export default function Login() {
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [error, setError] = React.useState('')
  const [loading, setLoading] = React.useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    try{
      const res = await fetch(`${apiBase()}/api/auth/login`, {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ email, password })
      })
      const data = await res.json()
      if(!res.ok) throw new Error(data.error || 'Failed')
      saveAuth(data.token, data.user)
      window.location.href = '/dashboard'
    }catch(err){
      setError(err.message)
    }finally{
      setLoading(false)
    }
  }

  return (
    <div style={{padding:24, maxWidth:420}}>
      <h2>Login</h2>
      {error && <p style={{color:'red'}}>{error}</p>}
      <form onSubmit={submit}>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} style={input}/>
        <input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} style={input}/>
        <button disabled={loading} type="submit" style={btn}>{loading? 'Signing in...' : 'Sign in'}</button>
      </form>
    </div>
  )
}

const input = { display:'block', width:'100%', padding:'10px 12px', margin:'8px 0', border:'1px solid #ccc', borderRadius:8 }
const btn = { padding:'12px 16px', borderRadius:8, border:'none', cursor:'pointer' }
