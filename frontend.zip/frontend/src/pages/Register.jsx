import React from 'react'
import { apiBase, saveAuth } from '../lib/api'

export default function Register() {
  const [form, setForm] = React.useState({
    name:'', phone:'', email:'', password:'',
    contributionAmount:'', frequency:'monthly',
    planMonths: '6', referredBy:''
  })
  const [error, setError] = React.useState('')
  const [loading, setLoading] = React.useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setLoading(true); setError('')
    try{
      const res = await fetch(`${apiBase()}/api/auth/register`, {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify(form)
      })
      const data = await res.json()
      if(!res.ok) throw new Error(data.error || 'Failed')
      saveAuth(data.token, data.user)
      alert(`Welcome ${data.user.name}! Your User ID is ${data.user.id}`)
      window.location.href = '/dashboard'
    }catch(err){
      setError(err.message)
    }finally{
      setLoading(false)
    }
  }

  const change = e => setForm(f => ({...f, [e.target.name]: e.target.value}))

  return (
    <div style={{padding:24, maxWidth:520}}>
      <h2>Create your EasySave account</h2>
      {error && <p style={{color:'red'}}>{error}</p>}
      <form onSubmit={submit}>
        <input name="name" placeholder="Full name" value={form.name} onChange={change} required style={input}/>
        <input name="phone" placeholder="Phone number" value={form.phone} onChange={change} required style={input}/>
        <input name="email" placeholder="Email" value={form.email} onChange={change} required style={input}/>
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={change} required style={input}/>
        <input name="contributionAmount" type="number" placeholder="Contribution amount" value={form.contributionAmount} onChange={change} required style={input}/>
        <select name="frequency" value={form.frequency} onChange={change} style={input}>
          <option value="monthly">Monthly</option>
          <option value="weekly">Weekly</option>
        </select>
        <select name="planMonths" value={form.planMonths} onChange={change} style={input}>
          <option value="3">3 months (3%)</option>
          <option value="6">6 months (5%)</option>
          <option value="9">9 months (7%)</option>
          <option value="12">12 months (10%)</option>
        </select>
        <input name="referredBy" placeholder="Referral code (optional)" value={form.referredBy} onChange={change} style={input}/>
        <button disabled={loading} type="submit" style={btn}>{loading? 'Creating...' : 'Create account'}</button>
      </form>
    </div>
  )
}

const input = { display:'block', width:'100%', padding:'10px 12px', margin:'8px 0', border:'1px solid #ccc', borderRadius:8 }
const btn = { padding:'12px 16px', borderRadius:8, border:'none', cursor:'pointer' }
