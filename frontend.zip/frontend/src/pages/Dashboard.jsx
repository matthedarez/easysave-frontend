import React from 'react'
import { apiBase, getAuth, getToken, clearAuth } from '../lib/api'

export default function Dashboard(){
  const [summary, setSummary] = React.useState(null)
  const [contribs, setContribs] = React.useState([])
  const [me, setMe] = React.useState(null)
  const [refBonus, setRefBonus] = React.useState(null)
  const [amount, setAmount] = React.useState('')

  const token = getToken()

  async function load(){
    const headers = { Authorization: `Bearer ${token}` }
    const [s, c, m, r] = await Promise.all([
      fetch(`${apiBase()}/api/summary`, { headers }).then(r=>r.json()),
      fetch(`${apiBase()}/api/contributions`, { headers }).then(r=>r.json()),
      fetch(`${apiBase()}/api/me`, { headers }).then(r=>r.json()),
      fetch(`${apiBase()}/api/referrals/bonus`, { headers }).then(r=>r.json()),
    ])
    setSummary(s); setContribs(c); setMe(m); setRefBonus(r)
  }

  React.useEffect(()=>{ load() }, [])

  async function addContribution(){
    const headers = { 'Content-Type':'application/json', Authorization: `Bearer ${token}` }
    const res = await fetch(`${apiBase()}/api/contributions`, { method:'POST', headers, body: JSON.stringify({ amount: Number(amount) }) })
    if(res.ok){ setAmount(''); load() }
  }

  function logout(){ clearAuth(); window.location.href='/' }

  return (
    <div style={{padding:24}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h2>Dashboard</h2>
        <button onClick={logout}>Logout</button>
      </div>
      {me && (
        <div style={card}>
          <p><b>Name:</b> {me.name}</p>
          <p><b>User ID:</b> {me._id}</p>
          <p><b>Plan:</b> {me.plan?.termMonths} months @ {(me.plan?.rate*100).toFixed(0)}%</p>
          <p><b>Contribution:</b> ₦{me.contributionAmount} / {me.frequency}</p>
          <p><b>Referral code:</b> {me.referralCode}</p>
        </div>
      )}
      {summary && (
        <div style={grid}>
          <div style={card}><h3>Total Saved</h3><p>₦{summary.totalSaved?.toLocaleString()}</p></div>
          <div style={card}><h3>Projected Interest</h3><p>₦{summary.projectedInterest?.toLocaleString()}</p></div>
          <div style={card}><h3>Maturity Date</h3><p>{new Date(summary.maturityDate).toDateString()}</p></div>
        </div>
      )}
      <div style={card}>
        <h3>Add Contribution</h3>
        <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Amount" style={{...input, maxWidth:200}}/>
        <button onClick={addContribution}>Add</button>
      </div>
      <div style={card}>
        <h3>Contribution History</h3>
        <table style={{width:'100%', borderCollapse:'collapse'}}>
          <thead>
            <tr><th align="left">Date</th><th align="right">Amount (₦)</th></tr>
          </thead>
          <tbody>
            {contribs.map(c => (
              <tr key={c._id}>
                <td>{new Date(c.date).toLocaleString()}</td>
                <td align="right">{c.amount.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {refBonus && (
        <div style={card}>
          <h3>Referral Bonus</h3>
          <p>Referred members: {refBonus.referredCount}</p>
          <p>Total referred savings: ₦{refBonus.totalReferredSavings?.toLocaleString()}</p>
          <p>Bonus (1.5%): ₦{refBonus.bonus?.toLocaleString()}</p>
        </div>
      )}
    </div>
  )
}

const grid = { display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(220px, 1fr))', gap:16 }
const card = { border:'1px solid #eee', padding:16, borderRadius:12, margin:'12px 0', boxShadow:'0 1px 3px rgba(0,0,0,0.05)' }
const input = { padding:'10px 12px', border:'1px solid #ccc', borderRadius:8, marginRight:8 }
