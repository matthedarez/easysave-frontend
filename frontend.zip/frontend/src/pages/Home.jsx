import React from 'react'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <div style={{padding:24}}>
      <h1>EasySave</h1>
      <p>Save weekly or monthly. Earn fixed interest at maturity.</p>
      <ul>
        <li>3 months — 3%</li>
        <li>6 months — 5%</li>
        <li>9 months — 7%</li>
        <li>12 months — 10%</li>
      </ul>
      <Link to="/register">Get Started →</Link>
    </div>
  )
}
