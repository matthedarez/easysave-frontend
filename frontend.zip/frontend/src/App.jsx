import React from 'react'
import { Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom'
import Home from './pages/Home'
import Register from './pages/Register'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import { getToken } from './lib/api'

function Nav() {
  const authed = !!getToken()
  return (
    <nav style={{display:'flex', gap:12, padding:12, borderBottom:'1px solid #ddd'}}>
      <Link to="/">EasySave</Link>
      <Link to="/register">Register</Link>
      <Link to="/login">Login</Link>
      {authed && <Link to="/dashboard">Dashboard</Link>}
    </nav>
  )
}

export default function App() {
  return (
    <div>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </div>
  )
}

function RequireAuth({ children }) {
  const token = getToken()
  const nav = useNavigate()
  React.useEffect(() => { if (!token) nav('/login') }, [token])
  return token ? children : null
}
